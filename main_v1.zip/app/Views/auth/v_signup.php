<?php echo $this->extend("layout/layout_utama"); ?>
<?php echo $this->section("konten_utama") ?> 

<h1>Ini halaman SignUp</h1>

<?php echo $this->endSection() ?> 