<?php echo $this->extend("layout/layout_utama"); ?>
<?php echo $this->section("konten_utama") ?> 


<?php echo $this->endSection() ?> 
